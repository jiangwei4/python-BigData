# Lancer le serveur
```
node serve.js
```

# Lancer le projet
```
pyhton Jeu.py
```


# Ajouter module
```
pyhton -m pip install module-name
```
